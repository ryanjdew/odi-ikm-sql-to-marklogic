print >> log, "flush and wait..."
writer.flushAndWait();
manager.stopJob(job);